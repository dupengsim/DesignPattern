﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Ruanmou.Homework.Model.Food;
using Ruanmou.Homework.Model.Soup;
using Ruanmou.Homework.Interface;

namespace Ruanmou.Homework.AbstractFactory
{
    public class HuaiYangFoodAbstractFactory : IHuaiYangFoodAbstractFactory
    {
        /// <summary>
        ///   以下是菜类
        /// </summary>
        /// <returns></returns>
        public AbstractFood CreateBraisedPolkBall()
        {
            return new BraisedPolkBall();
        }

        public AbstractFood CreateCrabPackage()
        {
            return new CrabPackage();
        }

        public AbstractFood CreateSquirrelFish()
        {
            return new SquirrelFish();
        }

        /// <summary>
        ///  以下是汤类
        /// </summary>
        /// <returns></returns>
        public AbstractSoup CreateTomatoEggSoup()
        {
            return new TomatoEggSoup();
        }

        public AbstractSoup CreateHotSourSoup()
        {
            return new HotSourSoup();
        }

        public AbstractSoup CreatePorkRibsSoup()
        {
            return new PorkRibsSoup();
        }
    }
}
