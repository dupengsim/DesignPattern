﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using Ruanmou.Homework.Model.Food;
using Ruanmou.Homework.Model.Enums;
using Ruanmou.Homework.Model.Order;
using Ruanmou.Homework.Helper;
using Ruanmou.Homework.SimpleFactory;
using Ruanmou.Homework.Factory;
using Ruanmou.Homework.Interface;
using Ruanmou.Homework.AbstractFactory;
using Ruanmou.Homework.Decorator;

namespace Ruanmou.Homework.Console
{
    class Program
    {
        private static object _orderObj = new object();
        static void Main(string[] args)
        {
            try
            {
                #region 1、普通实现
                {
                    System.Console.WriteLine("*******************1、普通方法调用 开始*******************");
                    AbstractFood braisedPolkBall = new BraisedPolkBall();
                    braisedPolkBall.ShowBasicInfo();
                    braisedPolkBall.ShowCookMethod();
                    braisedPolkBall.Taste();
                    AbstractFood crabPackage = new CrabPackage();
                    crabPackage.ShowBasicInfo();
                    crabPackage.ShowCookMethod();
                    crabPackage.Taste();
                    AbstractFood squirrelFish = new SquirrelFish();
                    squirrelFish.ShowBasicInfo();
                    squirrelFish.ShowCookMethod();
                    squirrelFish.Taste();
                    System.Console.WriteLine("*******************普通方法调用 结束*******************");
                    System.Console.WriteLine();
                }
                #endregion

                #region 2、简单工厂方式实现
                {
                    /**************************************
                    ** 优点：简单工厂降低了上端与实现层的耦合，由一个工厂类创建所有的对象实例，实现了上端的责任分离；
                    ** 缺点：工厂类中完成了所有对象的实例化逻辑，一旦一个对象创建失败，直接影响整个工厂类和整个系统的运行，违背了开闭的原则。
                    **************************************/
                    System.Console.WriteLine("*******************2、简单工厂方式 开始*******************");
                    // 利用枚举来创建
                    AbstractFood braisedPolkBall = FoodSimpleFactory.CreateInstanceByNormal(FoodTypeEnum.BraisedPolkBall);
                    braisedPolkBall.ShowBasicInfo();
                    braisedPolkBall.ShowCookMethod();
                    braisedPolkBall.Taste();
                    // 利用配置文件来创建
                    AbstractFood crabPackage = FoodSimpleFactory.CreateInstanceByConfig();
                    crabPackage.ShowBasicInfo();
                    crabPackage.ShowCookMethod();
                    crabPackage.Taste();
                    // 利用配置文件+反射方式创建
                    AbstractFood squirrelFish = FoodSimpleFactory.CreateInstanceByReflection(null);
                    squirrelFish.ShowBasicInfo();
                    squirrelFish.ShowCookMethod();
                    squirrelFish.Taste();

                    System.Console.WriteLine("*******************简单工厂方式 结束*******************");
                    System.Console.WriteLine();
                }
                #endregion

                #region 3、工厂方式实现
                {
                    /**************************************
                     ** 优点：克服了简单工厂中违背开闭原则的问题，保留了封装 对象创建过程的优点，在简单工厂的基础上进一步抽象，若增加新的对象时，只需增加对象的实现工厂，对原工厂没有影响；
                     ** 缺点：每增加一个新的产品时，都要相应的增加一个子工厂，大大增加了开发量，项目中的子类会越来越多。
                     **************************************/
                    System.Console.WriteLine("*******************3、工厂方式 开始*******************");
                    BaseFactory braisedPolkBallFactory = new BraisedPolkBallFactory();
                    AbstractFood braisedPolkBall = braisedPolkBallFactory.CreateInstance();
                    braisedPolkBall.ShowBasicInfo();
                    braisedPolkBall.ShowCookMethod();
                    braisedPolkBall.Taste();
                    System.Console.WriteLine("*******************工厂方式  结束*******************");
                    System.Console.WriteLine();
                }
                #endregion

                #region 4、抽象工厂方式实现
                {
                    /**************************************
                     ** 工厂模式中针对的是同一类产品的对象创建，而抽象工厂针对的是多个不同类型的产品，如本例中的菜品和汤是不同类别的，两者共同组成一个产品族
                     ** 优点：抽象工厂使得上端在创建对象时不必关注具体类是如何被创建，降低了耦合度，同时可以适应增加不同类型的产品（如增加一个汤或主食）；
                     ** 缺点：产品族的扩展比较麻烦，若要增加一个新的产品（如再增加一个主食）时，所有的工厂类都需要修改，又违背了开闭的原则。
                     **************************************/
                    System.Console.WriteLine("*******************4、抽象工厂方式 开始*******************");
                    IHuaiYangFoodAbstractFactory factory = new HuaiYangFoodAbstractFactory();
                    AbstractFood food = factory.CreateBraisedPolkBall();
                    food.ShowBasicInfo();
                    food.ShowCookMethod();
                    food.Taste();
                    System.Console.WriteLine("**配了一道汤**");
                    var soup = factory.CreateTomatoEggSoup();
                    soup.ShowBasicInfo();
                    soup.Taste();
                    System.Console.WriteLine("*******************抽象工厂方式  结束*******************");
                    System.Console.WriteLine();
                }
                #endregion

                #region 5、控制台点菜系统
                System.Console.WriteLine("******************5、控制台点菜系统******************");
                {
                    System.Console.WriteLine("下面是我们的菜单，请选择要点菜的编号：");
                    System.Console.WriteLine("*****************************************************");
                    #region 输出菜单列表
                    FoodMenu foodMenu = FoodMenu.CreateInstance();
                    var foodList = foodMenu.GetFoodMenuList();
                    if (foodList != null && foodList.FoodList.Count > 0)
                    {
                        foreach (var food in foodList.FoodList)
                        {
                            System.Console.WriteLine(" 编号：{0}{1}价格：{2}元 评分：{3}分", food.FoodId.ToString().PadRight(5), food.FoodName.PadRight(8), string.Format("{0:C}", food.Price).PadRight(8), food.FoodScore);
                        }
                        System.Console.WriteLine("*****************************************************");
                    }
                    #endregion
                    #region 手动输入菜品id，打印选择的菜品信息
                    System.Console.WriteLine("Please input food id and press enter to continue...");
                    int input = Convert.ToInt32(System.Console.ReadLine());
                    var selectedFood = foodList.FoodList.FirstOrDefault(c => c.FoodId == input);
                    if (selectedFood == null)
                    {
                        System.Console.WriteLine("客官，您点的菜本店没有，请换一个吧 ==||", System.ConsoleColor.Red);
                    }
                    else
                    {
                        System.Console.WriteLine(string.Format("您当前点了编号{0}的【{1}】，价格为：{2}，综合评分：{3}分", selectedFood.FoodId, selectedFood.FoodName, string.Format("{0:C}", selectedFood.Price), selectedFood.FoodScore));
                        AbstractFood absFood = FoodSimpleFactory.CreateInstanceByReflection(selectedFood.SimpleFactory);
                        absFood.ShowBasicInfo();
                        absFood.ShowCookMethod();
                        // 装饰器增加逻辑
                        IFoodProcessor processor = new FoodProcessor();
                        processor = new FoodProcessorDecorator(absFood);
                        processor.Cook();
                    }
                    #endregion

                    #region 多人无序随机点菜
                    System.Console.WriteLine();
                    System.Console.WriteLine("********************下面开始进入多线程点菜系统**********************");
                    OrderModel order = OrderInfoList.CreateInstance();
                    LogHelper.WriteInfoLog(string.Format("{0}来点餐", string.Join("、", order.CustomerList)), ConsoleColor.DarkGreen);
                    // 顾客点的菜放到此集合中
                    List<FoodModel> orderList;
                    // 每位顾客吃完评分最高的菜的集合
                    List<FoodModel> sortOrderList = new List<FoodModel>();
                    // 多线程的任务（三位顾客无序随机点菜）
                    List<Task> taskList = new List<Task>();
                    // 遍历所有的顾客
                    foreach (var customer in order.CustomerList)
                    {
                        Task task = Task.Factory.StartNew(() =>
                        {
                            orderList = foodMenu.GetFoodMenuListWithRandom();
                            LogHelper.WriteInfoLog(string.Format("客人{0}点了：{1}", customer, string.Join("，", orderList.Select(c => c.FoodName))));
                            // 保存顾客的信息，用于获取最高评分
                            Dictionary<int, int> dic = new Dictionary<int, int>();
                            foreach (var food in orderList)
                            {
                                AbstractFood afood = FoodSimpleFactory.CreateInstanceByReflection(food.SimpleFactory);
                                // 装饰器增加逻辑
                                IFoodProcessor processor = new FoodProcessor();
                                processor = new FoodProcessorDecorator(afood);
                                processor.Cook();
                                afood.baseFood.CustomerName = customer;
                                afood.Taste();
                                int score = afood.Score();
                                dic.Add(afood.baseFood.FoodId, score);
                            }
                            lock (_orderObj)
                            {
                                // 取出评分最高的一个
                                var maxScore = dic.OrderByDescending(c => c.Value).FirstOrDefault();
                                // 从菜单中获取评分最高的那道菜
                                var maxScoreFood = foodList.FoodList.FirstOrDefault(c => c.FoodId == maxScore.Key);
                                maxScoreFood.FoodScore = maxScore.Value;// 获取最高评分
                                sortOrderList.Add(maxScoreFood);
                                LogHelper.WriteInfoLog(string.Format("顾客{0}吃完所点的菜后，评分最高的菜是：{1}，评分：{2}", customer, maxScoreFood.FoodName, maxScoreFood.FoodScore));
                            }
                        });
                        taskList.Add(task);
                    }
                    Task.WaitAll(taskList.ToArray());// 所有线程任务都结束
                    // 获取所有顾客最终评分最高的菜
                    var finalMaxScoreFood = sortOrderList.OrderByDescending(c => c.FoodScore).FirstOrDefault();
                    if (finalMaxScoreFood != null)
                    {
                        LogHelper.WriteInfoLog(string.Format("所有顾客吃完各自所点的菜后，评分最高的菜是：{0}，评分：{1}", finalMaxScoreFood.FoodName, finalMaxScoreFood.FoodScore));
                    }
                    #endregion
                }
                #endregion

                #region 装饰器模式
                {
                    System.Console.WriteLine();
                    System.Console.WriteLine("*****************测试装饰器模式********************");
                    AbstractFood food = FoodSimpleFactory.CreateInstanceByNormal(FoodTypeEnum.BraisedPolkBall);
                    IFoodProcessor processor = new FoodProcessor();
                    processor = new FoodProcessorDecorator(food);
                    processor.Cook();
                } 
                #endregion

                System.Console.ReadKey();
            }
            catch (Exception ex)
            {
                LogHelper.WriteError(ex, null);
            }

        }
    }
}
