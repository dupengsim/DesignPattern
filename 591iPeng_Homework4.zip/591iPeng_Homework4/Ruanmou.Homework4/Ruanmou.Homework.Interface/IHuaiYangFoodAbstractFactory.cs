﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Ruanmou.Homework.Model.Food;
using Ruanmou.Homework.Model.Soup;

namespace Ruanmou.Homework.Interface
{
    /// <summary>
    ///  抽象工厂接口
    /// </summary>
    public interface IHuaiYangFoodAbstractFactory
    {
        AbstractFood CreateBraisedPolkBall();

        AbstractFood CreateCrabPackage();

        AbstractFood CreateSquirrelFish();


        AbstractSoup CreateTomatoEggSoup();

        AbstractSoup CreateHotSourSoup();

        AbstractSoup CreatePorkRibsSoup();
    }
}
