﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Ruanmou.Homework.Model.Food;

namespace Ruanmou.Homework.Factory
{
    /// <summary>
    ///  只负责创建红烧狮子头的工厂类
    /// </summary>
    public class BraisedPolkBallFactory : BaseFactory
    {
        public override Model.Food.AbstractFood CreateInstance()
        {
            return new BraisedPolkBall();
        }
    }
}
