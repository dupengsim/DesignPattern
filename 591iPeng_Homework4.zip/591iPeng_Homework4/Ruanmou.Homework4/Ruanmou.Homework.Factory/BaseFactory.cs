﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Ruanmou.Homework.Model.Food;

namespace Ruanmou.Homework.Factory
{
    /// <summary>
    ///  工厂类的基类
    /// </summary>
    public abstract class BaseFactory
    {

        public abstract AbstractFood CreateInstance();
    }
}
