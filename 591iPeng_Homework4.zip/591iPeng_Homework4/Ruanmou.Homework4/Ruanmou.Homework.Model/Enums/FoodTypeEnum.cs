﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace Ruanmou.Homework.Model.Enums
{
    /// <summary>
    ///  菜品类型枚举
    /// </summary>
    public enum FoodTypeEnum
    {
        /// <summary>
        /// 红烧狮子头
        /// </summary>
        [Description("红烧狮子头")]
        BraisedPolkBall,
        /// <summary>
        /// 蟹黄包
        /// </summary>
        [Description("蟹黄包")]
        CrabPackage,
        /// <summary>
        /// 松鼠鱼
        /// </summary>
        [Description("松鼠鱼")]
        SquirrelFish,
        /// <summary>
        ///  炒素鳝
        /// </summary>
        [Description("炒素鳝")]
        VegetarianEel,
        /// <summary>
        ///  三套鸭
        /// </summary>
        [Description("三套鸭")]
        ThreeNestedDuck
    }
}
