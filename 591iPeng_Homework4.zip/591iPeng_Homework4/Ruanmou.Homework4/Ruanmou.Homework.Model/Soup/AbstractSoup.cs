﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Ruanmou.Homework.Helper;

namespace Ruanmou.Homework.Model.Soup
{
    public abstract class AbstractSoup
    {
        public BaseSoup baseSoup { get; set; }

        public AbstractSoup(string configPath)
        {
            baseSoup = JsonHelper.ToObject<BaseSoup>(configPath);
        }

        /// <summary>
        ///  输出汤的描述信息
        /// </summary>
        public void ShowBasicInfo()
        {
            LogHelper.WriteInfoLog(string.Format("【编号】：{0}", baseSoup.SoupId), baseSoup.MessageColor);
            LogHelper.WriteInfoLog(string.Format("【汤名】：{0}", baseSoup.SoupName), baseSoup.MessageColor);
            LogHelper.WriteInfoLog(string.Format("【介绍】：{0}", baseSoup.SoupDescription), baseSoup.MessageColor);
        }

        /// <summary>
        ///  品尝
        /// </summary>
        public void Taste()
        {
            LogHelper.WriteInfoLog(string.Format("顾客正在喝{0}。。。", baseSoup.SoupName), baseSoup.MessageColor);
        }
    }
}
