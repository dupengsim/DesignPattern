﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ruanmou.Homework.Model.Soup
{
    /// <summary>
    ///  酸辣汤
    /// </summary>
    public class HotSourSoup : AbstractSoup
    {
        public HotSourSoup() : base("Config/HotSourSoup.json") { }
    }
}
