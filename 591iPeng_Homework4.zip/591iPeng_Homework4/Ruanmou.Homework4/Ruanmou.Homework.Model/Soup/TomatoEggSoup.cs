﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ruanmou.Homework.Model.Soup
{
    /// <summary>
    ///  西红柿鸡蛋汤
    /// </summary>
    public class TomatoEggSoup : AbstractSoup
    {

        public TomatoEggSoup() : base("Config/TomatoEggSoup.json") { }
    }
}
