﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ruanmou.Homework.Model.Soup
{
    /// <summary>
    ///  排骨汤
    /// </summary>
    public class PorkRibsSoup : AbstractSoup
    {
        public PorkRibsSoup() : base("Config/PorkRibsSoup.json") { }
    }
}
