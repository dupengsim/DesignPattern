﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ruanmou.Homework.Model.Soup
{
    /// <summary>
    ///  汤的基类
    /// </summary>
    public class BaseSoup
    {
        /// <summary>
        ///  编号
        /// </summary>
        public int SoupId { get; set; }
        /// <summary>
        ///  菜名
        /// </summary>
        public string SoupName { get; set; }
        /// <summary>
        ///  菜的描述信息
        /// </summary>
        public string SoupDescription { get; set; }
        /// <summary>
        ///  文字输出的颜色
        /// </summary>
        public ConsoleColor MessageColor { get; set; }
    }
}
