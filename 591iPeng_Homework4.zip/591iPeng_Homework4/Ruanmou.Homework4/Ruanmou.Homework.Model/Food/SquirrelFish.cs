﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ruanmou.Homework.Model.Food
{
    /// <summary>
    ///  松鼠鱼
    /// </summary>
    public class SquirrelFish : AbstractFood
    {

        public SquirrelFish() : base("Config/SquirrelFish.json") { }

    }
}
