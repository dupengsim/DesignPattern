﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Ruanmou.Homework.Helper;
using Ruanmou.Homework.Model.Order;

namespace Ruanmou.Homework.Model.Food
{
    /// <summary>
    ///  菜的父类
    /// </summary>
    public class BaseFood
    {
        #region 基本属性
        /// <summary>
        ///  编号
        /// </summary>
        public int FoodId { get; set; }
        /// <summary>
        ///  菜名
        /// </summary>
        public string FoodName { get; set; }
        /// <summary>
        ///  菜的描述信息
        /// </summary>
        public string FoodDescription { get; set; }
        /// <summary>
        ///  菜的做法
        /// </summary>
        public string CookMethod { get; set; }
        /// <summary>
        ///  价格
        /// </summary>
        public decimal Price { get; set; }
        /// <summary>
        ///  文字输出的颜色
        /// </summary>
        public ConsoleColor MessageColor { get; set; }
        #endregion


        /// <summary>
        /// 顾客基本配置信息
        /// </summary>
        public OrderModel CustomerOrder { get; set; }
        /// <summary>
        ///  顾客姓名
        /// </summary>
        public string CustomerName { get; set; }

        public BaseFood()
        {
            CustomerOrder = OrderInfoList.CreateInstance();
        }
    }
}
