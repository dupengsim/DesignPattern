﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ruanmou.Homework.Model.Food
{
    /// <summary>
    ///  炒素鳝
    /// </summary>
    public class VegetarianEel : AbstractFood
    {
        public VegetarianEel() : base("Config/VegetarianEel.json") { }

    }
}
