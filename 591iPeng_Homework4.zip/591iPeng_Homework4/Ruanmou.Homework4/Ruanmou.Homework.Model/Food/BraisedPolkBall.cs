﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Ruanmou.Homework.Helper;

namespace Ruanmou.Homework.Model.Food
{
    /// <summary>
    ///  红烧狮子头
    /// </summary>
    public class BraisedPolkBall : AbstractFood
    {
        public BraisedPolkBall() : base("Config/BraisedPolkBall.json") { }
    }
}
