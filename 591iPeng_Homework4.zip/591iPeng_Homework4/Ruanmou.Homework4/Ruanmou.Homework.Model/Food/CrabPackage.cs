﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ruanmou.Homework.Model.Food
{
    /// <summary>
    ///  蟹黄包
    /// </summary>
    public class CrabPackage : AbstractFood
    {
        public CrabPackage() : base("Config/CrabPackage.json") { }

    }
}
