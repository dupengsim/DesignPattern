﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ruanmou.Homework.Model.Food
{
    /// <summary>
    ///  三套鸭
    /// </summary>
    public class ThreeNestedDuck : AbstractFood
    {
        public ThreeNestedDuck() : base("Config/ThreeNestedDuck.json") { }

    }
}
