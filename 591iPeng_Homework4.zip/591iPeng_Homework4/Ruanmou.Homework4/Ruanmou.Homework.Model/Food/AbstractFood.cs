﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Ruanmou.Homework.Helper;
using Ruanmou.Homework.Model.Order;
using Ruanmou.Homework.Decorator;

namespace Ruanmou.Homework.Model.Food
{
    /// <summary>
    ///  菜品的基本约束
    /// </summary>
    public abstract class AbstractFood : IFoodProcessor
    {
        public BaseFood baseFood { get; set; }

        public AbstractFood(string configPath)
        {
            baseFood = JsonHelper.ToObject<BaseFood>(configPath);
        }

        /// <summary>
        ///  输出菜的描述信息
        /// </summary>
        public void ShowBasicInfo()
        {
            LogHelper.WriteInfoLog(string.Format("【编号】：{0}", baseFood.FoodId), baseFood.MessageColor);
            LogHelper.WriteInfoLog(string.Format("【菜名】：{0}", baseFood.FoodName), baseFood.MessageColor);
            LogHelper.WriteInfoLog(string.Format("【介绍】：{0}", baseFood.FoodDescription), baseFood.MessageColor);
        }

        /// <summary>
        ///  输出菜的做法
        /// </summary>
        public void ShowCookMethod()
        {
            LogHelper.WriteInfoLog(string.Format("【做法】：{0}", baseFood.CookMethod), baseFood.MessageColor);
        }
        /// <summary>
        ///  品尝
        /// </summary>
        public void Taste()
        {
            LogHelper.WriteInfoLog(string.Format("顾客{0}正在品尝{1}。。。", string.IsNullOrEmpty(baseFood.CustomerName) ? "" : baseFood.CustomerName, baseFood.FoodName), baseFood.MessageColor);
        }

        /// <summary>
        ///  评分
        /// </summary>
        public int Score()
        {
            //随机获取评分
            int scoreNum = new Random(DateTime.Now.Millisecond).Next(1, 6);
            string ScoreMsg = baseFood.CustomerOrder.FoodScoreMessage[scoreNum - 1];
            LogHelper.WriteInfoLog(string.Format(baseFood.CustomerOrder.ScoreMessage, baseFood.CustomerName, baseFood.FoodName, string.Format(ScoreMsg, scoreNum)));
            return scoreNum;
        }
        /// <summary>
        ///  准备
        /// </summary>
        public void Ready()
        {
            LogHelper.WriteInfoLog(string.Format("后厨正在准备您点的{0}。。。", baseFood.FoodName, baseFood.MessageColor));
        }


        public void Cook()
        {
            LogHelper.WriteInfoLog(string.Format("后厨正在做菜，您的是：{0}", baseFood.FoodName, baseFood.MessageColor));
        }
    }
}
