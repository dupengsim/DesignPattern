﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ruanmou.Homework.Model.Order
{
    public class FoodModelList
    {
        public List<FoodModel> FoodList { get; set; }
    }
}
