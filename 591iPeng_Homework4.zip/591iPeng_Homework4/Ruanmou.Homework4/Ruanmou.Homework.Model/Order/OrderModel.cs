﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ruanmou.Homework.Model.Order
{
    /// <summary>
    ///  xml文件中配置的客户点菜的相关信息
    /// </summary>
    public class OrderModel
    {
        /// <summary>
        ///  点菜信息
        /// </summary>
        public string OrderMessage { get; set; }
        /// <summary>
        ///  评论信息
        /// </summary>
        public string ScoreMessage { get; set; }
        /// <summary>
        ///  评分具体内容
        /// </summary>
        public List<string> FoodScoreMessage { get; set; }
        /// <summary>
        ///  客户列表
        /// </summary>
        public List<string> CustomerList { get; set; }
    }
}
