﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using Ruanmou.Homework.Helper;

namespace Ruanmou.Homework.Model.Order
{
    /// <summary>
    ///  单例模式读取客户订餐信息
    /// </summary>
    public sealed class OrderInfoList
    {

        private volatile static OrderModel _instance = null;
        private static readonly object _lockHelper = new object();
        private OrderInfoList() { }

        public static OrderModel CreateInstance()
        {
            if (_instance == null)
            {
                lock (_lockHelper)
                {
                    if (_instance == null)
                    {
                        var xmlPath = ConfigurationManager.AppSettings["XmlConfigPath"];
                        if (string.IsNullOrWhiteSpace(xmlPath))
                            throw new Exception("请在配置文件中设置菜品XML文件路径(节点名称为：XmlConfigPath)");
                        xmlPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, xmlPath);
                        if (!File.Exists(xmlPath))
                            throw new Exception(string.Format("配置文件：{0}不存在", xmlPath));
                        _instance = XmlHelper.FileToObject<OrderModel>(xmlPath);
                        if (_instance == null)
                            throw new Exception("基本信息配置文件读取失败");
                    }
                }
            }
            return _instance;
        }
    }
}
