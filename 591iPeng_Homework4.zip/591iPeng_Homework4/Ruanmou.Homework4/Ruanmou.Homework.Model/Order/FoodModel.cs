﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ruanmou.Homework.Model.Order
{
    public class FoodModel
    {
        /// <summary>
        ///  编号
        /// </summary>
        public int FoodId { get; set; }
        /// <summary>
        ///  菜品名称
        /// </summary>
        public string FoodName { get; set; }
        /// <summary>
        ///  描述信息
        /// </summary>
        public string FoodDescription { get; set; }
        /// <summary>
        ///  价格
        /// </summary>
        public decimal Price { get; set; }
        /// <summary>
        ///  评分
        /// </summary>
        public int FoodScore { get; set; }
        /// <summary>
        ///  评分信息
        /// </summary>
        public string FoodScoreMessage { get; set; }
        /// <summary>
        ///  颜色
        /// </summary>
        public ConsoleColor FoodColor { get; set; }
        /// <summary>
        ///  简单工厂创建时的dll配置信息
        /// </summary>
        public string SimpleFactory { get; set; }
    }
}
