﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using Ruanmou.Homework.Helper;

namespace Ruanmou.Homework.Model.Order
{
    /// <summary>
    /// 获取菜品配置信息
    /// </summary>
    public sealed class FoodMenu
    {
        /// <summary>
        /// 内部使用菜品列表变量
        /// </summary>
        private static FoodModelList _foodMenu;

        /// <summary>
        /// 禁止实例化
        /// </summary>
        private FoodMenu()
        {
            string xmlPath = ConfigurationManager.AppSettings["XmlFoodPath"];
            if (string.IsNullOrWhiteSpace(xmlPath))
                throw new Exception("请在配置文件中设置菜品XML文件路径(节点名称为：XmlFoodPath)");
            xmlPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, xmlPath);
            if (!File.Exists(xmlPath))
                throw new Exception(string.Format("配置文件：{0}不存在", xmlPath));
            _foodMenu = XmlHelper.FileToObject<FoodModelList>(xmlPath);
            if (null == _foodMenu)
                throw new Exception("菜品配置信息读取失败");
        }

        private static FoodMenu _FoodListInstance = null;

        /// <summary>
        /// 单例构造并读取菜品列表
        /// </summary>
        static FoodMenu()
        {
            _FoodListInstance = new FoodMenu();
        }

        public static FoodMenu CreateInstance()
        {
            return _FoodListInstance;
        }

        /// <summary>
        /// 获取菜品列表
        /// </summary>
        /// <returns></returns>
        public FoodModelList GetFoodMenuList()
        {
            return _foodMenu;
        }

        /// <summary>
        /// 获取菜品列表随机排序列表，并返回指定个数的菜
        /// </summary>
        /// <param name="takeNum">返回个数，0为全部</param>
        /// <returns></returns>
        public List<FoodModel> GetFoodMenuListWithRandom(int takeNum = 5)
        {
            if (takeNum > 0)
                return _foodMenu.FoodList.Select(a => new { a, newID = Guid.NewGuid() }).OrderBy(b => b.newID).Take(takeNum).Select(c => c.a).ToList();
            else
                return _foodMenu.FoodList.Select(a => new { a, newID = Guid.NewGuid() }).OrderBy(b => b.newID).Select(c => c.a).ToList();
        }

    }
}
