﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Ruanmou.Homework.Model.Food;
using Ruanmou.Homework.Model.Enums;
using System.Configuration;
using System.Reflection;

namespace Ruanmou.Homework.SimpleFactory
{
    /// <summary>
    ///  菜品的简单工厂模式
    /// </summary>
    public class FoodSimpleFactory
    {
        /// <summary>
        ///  利用枚举值来创建
        /// </summary>
        /// <param name="foodType">菜品类型</param>
        /// <returns></returns>
        public static AbstractFood CreateInstanceByNormal(FoodTypeEnum foodType)
        {
            switch (foodType)
            {
                case FoodTypeEnum.BraisedPolkBall:
                    return new BraisedPolkBall();
                case FoodTypeEnum.CrabPackage:
                    return new CrabPackage();
                case FoodTypeEnum.SquirrelFish:
                    return new SquirrelFish();
                default:
                    throw new Exception("对不起客官，本店没有此道菜，/(ㄒoㄒ)/~~");
            }
        }

        /// <summary>
        ///  根据配置文件来创建
        /// </summary>
        /// <returns></returns>
        public static AbstractFood CreateInstanceByConfig()
        {
            FoodTypeEnum foodType = (FoodTypeEnum)Enum.Parse(typeof(FoodTypeEnum), ConfigurationManager.AppSettings["SimpleFactory"]);
            return CreateInstanceByNormal(foodType);
        }

        private static readonly string classModule = ConfigurationManager.AppSettings["ReflectionFactory"];
        /// <summary>
        /// 利用配置文件+反射创建  
        /// </summary>
        /// <returns></returns>
        public static AbstractFood CreateInstanceByReflection(string configPath)
        {
            configPath = configPath ?? classModule;
            string _type = configPath.Split(',')[0];
            string _assembly = configPath.Split(',')[1];
            Assembly assembly = Assembly.Load(_assembly);
            Type type = assembly.GetType(_type);
            return (AbstractFood)Activator.CreateInstance(type);
        }
    }
}
