﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace Ruanmou.Homework.Helper
{
    /// <summary>
    /// XML文件系列化与反系列化
    /// </summary>
    public class XmlHelper
    {
        /// <summary>
        /// 文件反序列化成实体
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public static T FileToObject<T>(string path) where T : new()
        {
            path = path ?? AppDomain.CurrentDomain.BaseDirectory;
            string xml = File.ReadAllText(path, Encoding.UTF8);
            return XmlDeserialize<T>(xml, Encoding.UTF8);
        }

        /// <summary>
        /// 从XML字符串中反序列化对象
        /// </summary>
        /// <typeparam name="T">结果对象类型</typeparam>
        /// <param name="xmlStr">包含对象的XML字符串</param>
        /// <param name="encoding">编码方式</param>
        /// <returns>反序列化得到的对象</returns>
        public static T XmlDeserialize<T>(string xmlStr, Encoding encoding)
        {
            if (string.IsNullOrEmpty(xmlStr))
                throw new ArgumentNullException("xmlStr");
            if (encoding == null)
                throw new ArgumentNullException("encoding");
            XmlSerializer mySerializer = new XmlSerializer(typeof(T));
            using (MemoryStream ms = new MemoryStream(encoding.GetBytes(xmlStr)))
            {
                using (StreamReader sr = new StreamReader(ms, encoding))
                {
                    return (T)mySerializer.Deserialize(sr);
                }
            }
        }
    }
}
