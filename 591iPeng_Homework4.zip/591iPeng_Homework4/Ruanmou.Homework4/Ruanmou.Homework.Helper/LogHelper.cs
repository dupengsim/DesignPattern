﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;

namespace Ruanmou.Homework.Helper
{
    public class LogHelper
    {
        /// <summary>
        /// 静态锁
        /// </summary>
        private static readonly object _lock = new object();
        private static readonly object _writeLock = new object();
        private static readonly object _infoLock = new object();
        /// <summary>
        /// 记录错误日志
        /// </summary>
        /// <param name="ex"></param>
        public static void WriteError(Exception ex, string message)
        {
            if (ex != null)
            {
                lock (_lock)
                {
                    File.AppendAllText(AppDomain.CurrentDomain.BaseDirectory + "/runerror.txt",
                                      string.Format("{0}\r\n{1}\r\n{2}\r\n================================\r\n",
                                      DateTime.Now.ToString("yyyy-MM-dd HH:mm"), message + "--" + ex.Message, ex.StackTrace));
                }
            }
            else
            {
                lock (_lock)
                {
                    File.AppendAllText(AppDomain.CurrentDomain.BaseDirectory + "/runerror.txt",
                       string.Format("{0}\r\n{1}\r\n{2}\r\n================================\r\n",
                       DateTime.Now.ToString("yyyy-MM-dd HH:mm"), message + "--", ""));
                }
            }
        }

        /// <summary>
        ///  记录操作日志 
        /// </summary>
        /// <param name="msg"></param>
        public static void WriteInfo(string msg)
        {
            try
            {
                string fileName = DateTime.Now.ToString("yyyy-MM-dd");
                string filePath = AppDomain.CurrentDomain.BaseDirectory + "/logInfo";
                if (!Directory.Exists(filePath))
                {
                    Directory.CreateDirectory(filePath);
                }
                string virtualPath = filePath + "\\" + fileName + ".txt";
                string time = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
                msg = time + "，" + msg + System.Environment.NewLine;

                System.Threading.Tasks.Task.Factory.StartNew(() =>
                {
                    lock (_infoLock)
                    {
                        using (FileStream fs = new FileStream(virtualPath, FileMode.Append))
                        {
                            using (StreamWriter sw = new StreamWriter(fs))
                            {
                                sw.Write(msg);
                                //清空缓冲区               
                                sw.Flush();
                            }
                        }
                    }
                });
            }
            catch (Exception ex)
            {
                WriteError(ex, null);
            }
        }

        /// <summary>
        /// 输出信息到控制台并写入提示日志
        /// </summary>
        /// <param name="ex">异常信息</param>
        /// <param name="e">线程挂起方式</param>
        /// <param name="c">文本颜色</param>
        public static void WriteInfoLog(string message, ConsoleColor c = ConsoleColor.White)
        {
            //锁在日志输出，防止颜色混乱
            lock (_writeLock)
            {
                //挂起，让信息间隔输出
                Thread.Sleep(500);
                //输出到控制台
                Console.ForegroundColor = c;
                Console.WriteLine(message);
                Console.ForegroundColor = ConsoleColor.White;
            }
            //写入日志文件
            WriteInfo(message);
        }
    }
}
