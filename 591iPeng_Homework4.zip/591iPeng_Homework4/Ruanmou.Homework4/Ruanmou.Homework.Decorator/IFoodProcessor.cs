﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ruanmou.Homework.Decorator
{
    /// <summary>
    ///  定义做菜的接口
    /// </summary>
    public interface IFoodProcessor
    {
        /// <summary>
        ///  做菜的方法
        /// </summary>
        void Cook();
    }
}
