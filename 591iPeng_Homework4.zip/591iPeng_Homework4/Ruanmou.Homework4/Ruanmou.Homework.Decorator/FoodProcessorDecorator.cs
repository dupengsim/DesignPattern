﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ruanmou.Homework.Decorator
{
    public class FoodProcessorDecorator : IFoodProcessor
    {
        private IFoodProcessor FoodProsessor { get; set; }
        public FoodProcessorDecorator(IFoodProcessor foodProsessor)
        {
            FoodProsessor = foodProsessor;
        }
        public void Cook()
        {
            BeforeCooking();
            this.FoodProsessor.Cook();
            AfterCooking();
        }

        /// <summary>
        ///  做菜前的准备工作
        /// </summary>
        public void BeforeCooking()
        {
            Console.WriteLine("做菜前的准备工作：买菜、洗菜、切菜。。。");
        }
        /// <summary>
        ///  做菜后的动作
        /// </summary>
        public void AfterCooking()
        {
            Console.WriteLine("做菜后的工作：摆盘、上菜。。。");
        }
    }
}
