﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ruanmou.Homework.Decorator
{
    public class FoodProcessor : IFoodProcessor
    {
        public void Cook()
        {
            Console.WriteLine("正在做菜。。。");
        }
    }
}
